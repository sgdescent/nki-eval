def kernel(a, b): return (a + b).double()
