calls = 0
def kernel(a, b):
 global calls
 calls += 1
 if calls > 2:
  raise RuntimeError('injected warmup failure')
 return a + b

