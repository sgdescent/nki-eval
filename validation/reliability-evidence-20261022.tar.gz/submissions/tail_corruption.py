def kernel(a, b):
 out = a + b
 out[:, -1] = 0
 return out
