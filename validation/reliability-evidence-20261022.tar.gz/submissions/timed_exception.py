calls = 0
def kernel(a, b):
 global calls
 calls += 1
 if calls > 4:
  raise RuntimeError('injected timed failure')
 return a + b

