def kernel(a, b): return b + a
